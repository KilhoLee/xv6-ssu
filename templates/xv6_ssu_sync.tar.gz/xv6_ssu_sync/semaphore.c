#include "types.h"
#include "defs.h"
#include "param.h"
#include "x86.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "spinlock.h"
#include "semaphore.h"

void
sem_init(struct semaphore *s, int init_value)
{
  /* ******************** */
  /* * WRITE YOUR CODE    */
  /* ******************** */
}

void
sem_wait(struct semaphore *s)
{
  /* ******************** */
  /* * WRITE YOUR CODE    */
  /* ******************** */
}

void
sem_post(struct semaphore *s)
{
  /* ******************** */
  /* * WRITE YOUR CODE    */
  /* ******************** */
}

void
sem_destroy(struct semaphore *s)
{
  /* ******************** */
  /* * WRITE YOUR CODE    */
  /* ******************** */
}
