struct semaphore {

  /* ******************** */
  /* * WRITE YOUR CODE    */
  /* ******************** */

};

extern struct semaphore usema[NLOCK];
